const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema(
  {
    chat: { type: mongoose.Schema.Types.ObjectId, ref: "Chat", required: true, index: true },
    role: { type: String, enum: ["user", "assistant"], required: true },
    content: { type: String, required: true },

    // null = no reaction yet, true = liked, false = disliked
    liked: { type: Boolean, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Message", MessageSchema);
