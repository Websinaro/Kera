const express = require("express");
const { nanoid } = require("nanoid");
const Chat = require("../models/Chat");
const Message = require("../models/Message");
const auth = require("../middleware/auth");
const { rateLimit } = require("../middleware/rateLimit");
const { generateReply } = require("../utils/hfInference");
const { generateImage, generateImageEdit } = require("../utils/hfImage");
const { uploadImage } = require("../utils/cloudinary");

const router = express.Router();
const SHARE_TTL_MS = (Number(process.env.SHARE_LINK_TTL_HOURS) || 2) * 60 * 60 * 1000;

// Image messages store a huge base64 data URL as their content - never send
// that to the text model (it blows past token limits instantly). Swap it
// for a short text summary instead so Kera still "remembers" it happened.
function toModelHistory(messages) {
  const MAX_CHARS = 6000; // defensive cap so no single turn can blow the token budget
  return messages.map((m) => {
    if (m.type === "image") {
      const content =
        m.role === "user"
          ? `[The user uploaded a reference image here${m.imagePrompt && m.imagePrompt !== "Uploaded reference image" ? ` (${m.imagePrompt})` : ""}. I can't see the image myself, only that it was uploaded.]`
          : `[I generated an image here for the prompt: "${m.imagePrompt || "unspecified"}". I can't see the image myself, only that I made it.]`;
      return { role: m.role, content };
    }
    const content =
      m.content.length > MAX_CHARS ? m.content.slice(0, MAX_CHARS) + " …[truncated]" : m.content;
    return { role: m.role, content };
  });
}

// All routes below require auth
router.use(auth);

// ---- List chats ----
router.get("/", async (req, res, next) => {
  try {
    const chats = await Chat.find({ user: req.user._id }).sort({ updatedAt: -1 });
    res.json({ chats });
  } catch (err) {
    next(err);
  }
});

// ---- Create chat ----
router.post("/", async (req, res, next) => {
  try {
    const { title, instructions } = req.body;
    const chat = await Chat.create({
      user: req.user._id,
      title: title || "New chat",
      instructions: instructions || "",
    });
    res.status(201).json({ chat });
  } catch (err) {
    next(err);
  }
});

// ---- Get one chat + its messages ----
router.get("/:id", async (req, res, next) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    const messages = await Message.find({ chat: chat._id }).sort({ createdAt: 1 });
    res.json({ chat, messages });
  } catch (err) {
    next(err);
  }
});

// ---- Update chat instructions / title ----
router.put("/:id", async (req, res, next) => {
  try {
    const { title, instructions } = req.body;
    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    if (typeof title === "string") chat.title = title;
    if (typeof instructions === "string") chat.instructions = instructions;
    await chat.save();

    res.json({ chat });
  } catch (err) {
    next(err);
  }
});

// ---- Delete chat ----
router.delete("/:id", async (req, res, next) => {
  try {
    const chat = await Chat.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });
    await Message.deleteMany({ chat: chat._id });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// ---- Send a message and get the model's reply ----
router.post("/:id/messages", rateLimit, async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: "Message content is required." });
    }

    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    const userMessage = await Message.create({
      chat: chat._id,
      role: "user",
      content: content.trim(),
    });

    // Auto-title the chat from the first message
    if (chat.title === "New chat") {
      chat.title = content.trim().slice(0, 60);
    }
    chat.updatedAt = new Date();
    await chat.save();

    const history = await Message.find({ chat: chat._id }).sort({ createdAt: 1 }).limit(40);

    const imageMatch = content.trim().match(/^\/(image|img)\b\s*([\s\S]*)$/i);

    let assistantMessage;

    if (imageMatch) {
      // ---- "/image <prompt>" -> generate an image instead of text ----
      const imagePrompt = imageMatch[2].trim();

      if (!imagePrompt) {
        assistantMessage = await Message.create({
          chat: chat._id,
          role: "assistant",
          content: "Tell me what to draw! For example: `/image a fox curled up in the snow, soft lighting` 🎨",
        });
      } else {
        try {
          let dataUrl;
          let editWarning = null;
          if (chat.referenceImageUrl) {
            try {
              dataUrl = await generateImageEdit(imagePrompt, chat.referenceImageUrl);
            } catch (editErr) {
              // Editing isn't working right now (wrong task/provider, bad
              // input, etc.) - fall back to a fresh generation rather than
              // failing the request outright, but tell the user clearly
              // why, instead of silently swapping images on them.
              console.error("[chat] generateImageEdit failed, falling back to text-to-image:", editErr.message);
              dataUrl = await generateImage(imagePrompt);
              editWarning = `Editing your uploaded image didn't work right now (${editErr.message}), so here's a fresh image from the prompt alone instead.`;
            }
          } else {
            dataUrl = await generateImage(imagePrompt);
          }

          let finalUrl = dataUrl;
          try {
            finalUrl = await uploadImage(dataUrl);
          } catch (uploadErr) {
            // If Cloudinary upload fails for some reason, fall back to
            // storing the base64 data URL directly so the feature still
            // works - just without the CDN/storage benefits.
            console.error("[chat] Cloudinary upload failed, falling back to inline image:", uploadErr.message);
          }
          assistantMessage = await Message.create({
            chat: chat._id,
            role: "assistant",
            type: "image",
            content: finalUrl,
            imagePrompt,
          });

          return res.status(201).json({ userMessage, assistantMessage, usage: req.usage, warning: editWarning });
        } catch (genErr) {
          console.error("[chat] generateImage failed:", genErr.message);
          assistantMessage = await Message.create({
            chat: chat._id,
            role: "assistant",
            content: `⚠️ Sorry, I couldn't generate that image right now (${genErr.message}). Please try again in a few seconds.`,
          });
        }
      }
    } else {
      // ---- Normal text reply ----
      try {
        const replyText = await generateReply(chat.instructions, toModelHistory(history));
        assistantMessage = await Message.create({
          chat: chat._id,
          role: "assistant",
          content: replyText,
        });
      } catch (genErr) {
        console.error("[chat] generateReply failed:", genErr.message);
        assistantMessage = await Message.create({
          chat: chat._id,
          role: "assistant",
          content: `⚠️ Sorry, I couldn't generate a reply right now (${genErr.message}). Please try again in a few seconds.`,
        });
      }
    }

    res.status(201).json({
      userMessage,
      assistantMessage,
      usage: req.usage,
    });
  } catch (err) {
    next(err);
  }
});

// ---- Upload a reference image (for image-based memory / editing) ----
router.post("/:id/reference-image", rateLimit, async (req, res, next) => {
  try {
    const { imageDataUrl } = req.body;
    if (!imageDataUrl || !imageDataUrl.startsWith("data:image/")) {
      return res.status(400).json({ error: "A valid image is required." });
    }

    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    let url = imageDataUrl;
    try {
      url = await uploadImage(imageDataUrl);
    } catch (uploadErr) {
      console.error("[chat] reference image Cloudinary upload failed, using inline data:", uploadErr.message);
    }

    chat.referenceImageUrl = url;
    await chat.save();

    const userMessage = await Message.create({
      chat: chat._id,
      role: "user",
      type: "image",
      content: url,
      imagePrompt: "Uploaded reference image",
    });

    const assistantMessage = await Message.create({
      chat: chat._id,
      role: "assistant",
      content:
        "Got it — I'll remember this image. 🖼️ Type `/image <what to change>` and I'll edit it, or upload a new one to replace it anytime.",
    });

    res.status(201).json({ chat, userMessage, assistantMessage, usage: req.usage });
  } catch (err) {
    next(err);
  }
});

// ---- Clear the chat's reference image ----
router.delete("/:id/reference-image", async (req, res, next) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    chat.referenceImageUrl = null;
    await chat.save();

    res.json({ chat });
  } catch (err) {
    next(err);
  }
});

// ---- Like / dislike a message ----
router.post("/messages/:messageId/react", async (req, res, next) => {
  try {
    const { liked } = req.body; // true, false, or null to clear
    const message = await Message.findById(req.params.messageId).populate("chat");
    if (!message || String(message.chat.user) !== String(req.user._id)) {
      return res.status(404).json({ error: "Message not found." });
    }
    message.liked = liked;
    await message.save();
    res.json({ message });
  } catch (err) {
    next(err);
  }
});

// ---- Create / refresh a share link (valid for SHARE_TTL_MS) ----
router.post("/:id/share", async (req, res, next) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    chat.shareToken = nanoid(12);
    chat.shareExpiresAt = new Date(Date.now() + SHARE_TTL_MS);
    await chat.save();

    res.json({ shareToken: chat.shareToken, shareExpiresAt: chat.shareExpiresAt });
  } catch (err) {
    next(err);
  }
});

// ---- Revoke a share link ----
router.delete("/:id/share", async (req, res, next) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.id, user: req.user._id });
    if (!chat) return res.status(404).json({ error: "Chat not found." });

    chat.shareToken = null;
    chat.shareExpiresAt = null;
    await chat.save();

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
