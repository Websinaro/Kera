const axios = require("axios");

const HF_URL =
  process.env.HF_INFERENCE_URL ||
  `https://api-inference.huggingface.co/models/${process.env.HF_MODEL || "websinaro/kera-1.5b-instruct"}`;

// Baseline behaviour rules appended to every chat's own instructions so the
// model formats replies consistently: sensible emoji use, clean spacing,
// and correctly fenced code blocks.
const BASE_STYLE_GUIDE = `You are Kera, a helpful, friendly AI assistant.
Formatting rules you must always follow:
- Use clear paragraphs and blank lines between ideas, never wall-of-text.
- Use emojis sparingly and only where they add real meaning (e.g. one at the
  start of a short tip, or to mark a list item's tone) - never spam emojis.
- Use markdown for structure: **bold** for key terms, bullet lists for steps,
  and numbered lists for sequences.
- Always wrap code in fenced code blocks with the correct language tag,
  e.g. \`\`\`js ... \`\`\`.
- Keep spacing clean: no double blank lines, no trailing whitespace, no
  random extra indentation.
- Be concise and accurate; avoid filler.`;

// Matches websinaro/kera-1.5b-instruct's actual chat_template.jinja, which is
// the standard Qwen ChatML format: <|im_start|>role\ncontent<|im_end|>\n
// (see https://huggingface.co/websinaro/kera-1.5b-instruct/resolve/main/chat_template.jinja)
function buildPrompt(systemInstructions, history) {
  const system = [BASE_STYLE_GUIDE, systemInstructions?.trim()].filter(Boolean).join("\n\n");

  let prompt = `<|im_start|>system\n${system}<|im_end|>\n`;
  for (const msg of history) {
    const role = msg.role === "user" ? "user" : "assistant";
    prompt += `<|im_start|>${role}\n${msg.content}<|im_end|>\n`;
  }
  prompt += `<|im_start|>assistant\n`;
  return prompt;
}

/**
 * Calls the Hugging Face Inference API (serverless). The 3.9GB model is
 * never loaded into this server's own process/RAM - HF hosts and runs it,
 * which is exactly what keeps a free-tier backend instance from crashing.
 */
async function generateReply(systemInstructions, history, { retries = 3 } = {}) {
  if (!process.env.HF_TOKEN) {
    throw new Error("HF_TOKEN is not set. Add your Hugging Face access token to the environment.");
  }

  const prompt = buildPrompt(systemInstructions, history);

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const { data } = await axios.post(
        HF_URL,
        {
          inputs: prompt,
          parameters: {
            max_new_tokens: 512,
            temperature: 0.7,
            top_p: 0.9,
            repetition_penalty: 1.1,
            return_full_text: false,
            // ChatML end-of-turn / next-turn tokens - stops generation cleanly
            // even if the backend doesn't fully honour `stop`, cleanUp() below
            // trims anything that leaks through as a safety net.
            stop: ["<|im_end|>", "<|im_start|>"],
          },
          options: {
            // Let HF cold-start the model on demand instead of failing
            // immediately - this is the "serverless" behaviour we rely on.
            wait_for_model: true,
            use_cache: false,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.HF_TOKEN}`,
            "Content-Type": "application/json",
          },
          timeout: 60000,
        }
      );

      let text = "";
      if (Array.isArray(data) && data[0]?.generated_text) {
        text = data[0].generated_text;
      } else if (typeof data?.generated_text === "string") {
        text = data.generated_text;
      } else {
        text = String(data);
      }

      return cleanUp(text);
    } catch (err) {
      const status = err.response?.status;
      const estimatedTime = err.response?.data?.estimated_time;

      // Model is warming up on HF's side - wait and retry.
      if (status === 503 && attempt < retries) {
        const wait = Math.min(Math.ceil((estimatedTime || 5) * 1000), 15000);
        await new Promise((r) => setTimeout(r, wait));
        continue;
      }

      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
        continue;
      }

      const message =
        err.response?.data?.error || err.message || "Hugging Face inference request failed.";
      throw new Error(message);
    }
  }
}

function cleanUp(text) {
  return text
    // Cut off anything from the next ChatML turn onward, in case the model
    // (or the API) doesn't fully respect the `stop` parameter.
    .replace(/<\|im_end\|>[\s\S]*$/, "")
    .replace(/<\|im_start\|>[\s\S]*$/, "")
    .replace(/<\|im_end\|>/g, "")
    .replace(/<\|im_start\|>/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

module.exports = { generateReply };
