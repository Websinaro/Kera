import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import CodeBlock from "./CodeBlock.jsx";
import { api } from "../api/api.js";

export default function MessageBubble({ message, readOnly }) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(message.liked);

  const copyMessage = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const react = async (value) => {
    if (readOnly) return;
    const next = liked === value ? null : value;
    setLiked(next);
    try {
      await api.reactMessage(message._id, next);
    } catch {
      // non-critical, ignore
    }
  };

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} px-4`}>
      <div className={`max-w-[75ch] w-fit ${isUser ? "items-end" : "items-start"} flex flex-col gap-1.5`}>
        <div
          className={`rounded-xl2 px-4 py-3 text-[0.93rem] ${
            isUser
              ? "bg-signal text-white rounded-br-md"
              : "bg-panel2 border border-line text-paper rounded-bl-md"
          }`}
        >
          {isUser ? (
            <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
          ) : (
            <div className="prose-kera">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ inline, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || "");
                    const value = String(children).replace(/\n$/, "");
                    if (inline) {
                      return (
                        <code className={className} {...props}>
                          {children}
                        </code>
                      );
                    }
                    return <CodeBlock language={match?.[1]} value={value} />;
                  },
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </div>

        {!readOnly && (
          <div className={`flex items-center gap-1 text-mist text-xs ${isUser ? "pr-1" : "pl-1"}`}>
            <button
              onClick={copyMessage}
              className="px-1.5 py-1 rounded-md hover:bg-white/5 hover:text-paper transition-colors"
              title="Copy message"
            >
              {copied ? "Copied ✓" : "⧉ Copy"}
            </button>
            {!isUser && (
              <>
                <button
                  onClick={() => react(true)}
                  className={`px-1.5 py-1 rounded-md hover:bg-white/5 transition-colors ${
                    liked === true ? "text-good" : "hover:text-paper"
                  }`}
                  title="Like"
                >
                  👍
                </button>
                <button
                  onClick={() => react(false)}
                  className={`px-1.5 py-1 rounded-md hover:bg-white/5 transition-colors ${
                    liked === false ? "text-bad" : "hover:text-paper"
                  }`}
                  title="Dislike"
                >
                  👎
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
